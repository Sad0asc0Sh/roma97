<?php
declare(strict_types=1);

if (!defined('ROOMA_APP')) {
    die('Access denied.');
}

require_once __DIR__ . '/functions.php';

function startSecureSession(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_strict_mode', '1');

    // Use a custom session save path on cPanel shared hosting for isolation.
    if (defined('SESSION_SAVE_PATH') && SESSION_SAVE_PATH !== '') {
        $sessionDir = SESSION_SAVE_PATH;
        if (!is_dir($sessionDir)) {
            @mkdir($sessionDir, 0700, true);
        }
        if (is_dir($sessionDir) && is_writable($sessionDir)) {
            ini_set('session.save_path', $sessionDir);
        }
    }

    // Use the isHttps() function for consistency
    $isSecure = isHttps();

    // Also set session.cookie_secure in ini
    ini_set('session.cookie_secure', $isSecure ? '1' : '0');

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $isSecure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    session_start();

    // Idle-timeout enforcement. A rolling window guards against a stolen session
    // cookie on an abandoned device: even though the cookie persists (lifetime 0),
    // activity older than SESSION_IDLE_TIMEOUT is treated as expired.
    enforceSessionIdleTimeout();
}

/**
 * Hard cap on inactivity. Defaults to 2 hours; override via SESSION_IDLE_TIMEOUT
 * in config.local.php (seconds). Falls back to 7200 when undefined.
 */
function sessionIdleTimeoutSeconds(): int
{
    $configured = defined('SESSION_IDLE_TIMEOUT') ? (int) SESSION_IDLE_TIMEOUT : 0;

    return $configured > 0 ? $configured : 7200;
}

/**
 * Expire the session if it has been idle for too long. Clears the authentication
 * markers so the role guards (requireLogin / requireParentLogin / requireTeacherLogin)
 * redirect to the login page on the next request.
 */
function enforceSessionIdleTimeout(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return;
    }

    $now = time();

    if (!isset($_SESSION['last_activity'])) {
        $_SESSION['last_activity'] = $now;

        return;
    }

    if (($now - (int) $_SESSION['last_activity']) > sessionIdleTimeoutSeconds()) {
        // Session expired by inactivity — destroy it cleanly and start fresh.
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                $now - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        session_destroy();
        session_start();
        session_regenerate_id(true);

        return;
    }

    // Roll the activity timestamp. We do NOT regenerate the id on every request
    // (that breaks concurrent requests / back-button navigation); the login flows
    // already regenerate on privilege change.
    $_SESSION['last_activity'] = $now;
}

startSecureSession();

/**
 * Brute-force throttling, persisted in the database and keyed by client IP
 * (and optionally a per-account identifier such as an email/username).
 *
 * This intentionally does NOT rely on the visitor's session/cookies: a
 * session-based counter can be reset at will by the attacker simply by
 * dropping the session cookie between attempts, which defeats the lockout
 * entirely. Persisting the counter server-side closes that gap.
 */
const BRUTE_FORCE_MAX_ATTEMPTS = 5;
const BRUTE_FORCE_LOCKOUT_SECONDS = 900; // 15 minutes

/**
 * Create the login_throttle table (idempotent, cached per-request).
 */
function initializeLoginThrottleTable(): void
{
    // Schema is created at install time via setup.php / schema.sql
    static $initialized = false;
    $initialized = true;
}

/**
 * The client's IP address, truncated to fit the storage column.
 */
function bruteForceClientIp(): string
{
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');

    return substr($ip, 0, 45);
}

/**
 * Build the list of [keyType, keyValue] throttle rows that apply to this attempt:
 * always the client IP, and additionally the supplied account identifier
 * (e.g. username/email) when given. Checking both means a single account can't
 * be brute-forced from many IPs, and a single IP can't brute-force many accounts.
 *
 * @return array<int, array{0:string,1:string}>
 */
function bruteForceKeys(?string $identifier): array
{
    $keys = [['ip', bruteForceClientIp()]];

    $identifier = $identifier !== null ? mb_strtolower(trim($identifier), 'UTF-8') : '';
    if ($identifier !== '') {
        $keys[] = ['identifier', substr($identifier, 0, 191)];
    }

    return $keys;
}

/**
 * Whether the given context/identifier combination is currently allowed to
 * attempt a login. Returns false if EITHER the IP or the account identifier
 * is currently locked out.
 */
function checkBruteForce(string $context = 'login', ?string $identifier = null): bool
{
    try {
        initializeLoginThrottleTable();
        $pdo = getDb();

        $stmt = $pdo->prepare(
            'SELECT locked_until FROM login_throttle
             WHERE context = :context AND key_type = :type AND key_value = :value
             LIMIT 1'
        );
        $clear = $pdo->prepare(
            'DELETE FROM login_throttle WHERE context = :context AND key_type = :type AND key_value = :value'
        );

        foreach (bruteForceKeys($identifier) as [$type, $value]) {
            $stmt->execute([':context' => $context, ':type' => $type, ':value' => $value]);
            $row = $stmt->fetch();

            if ($row === false || $row['locked_until'] === null) {
                continue;
            }

            $lockedUntil = new DateTimeImmutable((string) $row['locked_until']);
            if (new DateTimeImmutable() < $lockedUntil) {
                return false; // Still locked out.
            }

            // The lockout window has elapsed — clear the row so the next
            // failure starts a fresh count rather than immediately re-locking
            // (attempts would otherwise just keep climbing past the threshold).
            $clear->execute([':context' => $context, ':type' => $type, ':value' => $value]);
        }

        return true;
    } catch (Throwable $e) {
        // If the throttle store itself is unavailable, fail open rather than
        // blocking every login on an unrelated infrastructure problem — the
        // credential check that follows still protects the account.
        error_log('checkBruteForce failed: ' . $e->getMessage());
        return true;
    }
}

/**
 * Record a failed login attempt for both the client IP and (if given) the
 * account identifier, locking out whichever one crosses the threshold.
 */
function recordFailedAttempt(string $context = 'login', ?string $identifier = null): void
{
    try {
        initializeLoginThrottleTable();
        $pdo = getDb();

        $upsert = $pdo->prepare(
            'INSERT INTO login_throttle (context, key_type, key_value, attempts, locked_until)
             VALUES (:context, :type, :value, 1, NULL)
             ON DUPLICATE KEY UPDATE
                attempts = attempts + 1,
                locked_until = IF(attempts >= :max_attempts, :locked_until, locked_until)'
        );

        $lockedUntil = (new DateTimeImmutable())
            ->modify('+' . BRUTE_FORCE_LOCKOUT_SECONDS . ' seconds')
            ->format('Y-m-d H:i:s');

        foreach (bruteForceKeys($identifier) as [$type, $value]) {
            $upsert->execute([
                ':context' => $context,
                ':type' => $type,
                ':value' => $value,
                ':max_attempts' => BRUTE_FORCE_MAX_ATTEMPTS,
                ':locked_until' => $lockedUntil,
            ]);
        }
    } catch (Throwable $e) {
        error_log('recordFailedAttempt failed: ' . $e->getMessage());
    }
}

/**
 * Clear throttle state on successful login.
 */
function resetLoginAttempts(string $context = 'login', ?string $identifier = null): void
{
    try {
        initializeLoginThrottleTable();
        $pdo = getDb();

        $delete = $pdo->prepare(
            'DELETE FROM login_throttle WHERE context = :context AND key_type = :type AND key_value = :value'
        );

        foreach (bruteForceKeys($identifier) as [$type, $value]) {
            $delete->execute([':context' => $context, ':type' => $type, ':value' => $value]);
        }
    } catch (Throwable $e) {
        error_log('resetLoginAttempts failed: ' . $e->getMessage());
    }
}

/**
 * Invalidate any CSRF token carried over in the session. Call this right after
 * session_regenerate_id() on a successful login so a token issued to the
 * pre-authentication (anonymous) session cannot be reused on the authenticated one.
 */
function rotateCsrfToken(): void
{
    unset($_SESSION['csrf_token']);
}

function isLoggedIn(): bool
{
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function requireLogin(): void
{
    if (!isLoggedIn()) {
        redirect(url('admin/login.php'));
    }

    $currentPage = 'admin/' . basename($_SERVER['PHP_SELF'] ?? '');
    if (!isPageAllowedForRole($currentPage, currentAdminRole())) {
        setFlash('error', 'شما دسترسی به این بخش را ندارید.');
        redirect(url('admin/index.php'));
    }
}

function currentAdminRole(): string
{
    return (string) ($_SESSION['admin_role'] ?? 'owner');
}

function requireAdminRole(array $allowedRoles): void
{
    requireLogin();
    if (!in_array(currentAdminRole(), $allowedRoles, true)) {
        setFlash('error', 'شما دسترسی به این بخش را ندارید.');
        redirect(url('admin/index.php'));
    }
}

function isPageAllowedForRole(string $pagePath, string $role): bool
{
    require_once __DIR__ . '/permissions.php';
    $matrix = adminPermissionsMatrix();
    $allowedPages = $matrix[$role] ?? $matrix['owner'];

    return in_array($pagePath, $allowedPages, true);
}

function isParentLoggedIn(): bool
{
    return isset($_SESSION['parent_id'])
        && filter_var($_SESSION['parent_id'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) !== false;
}

function requireParentLogin(): void
{
    if (!isParentLoggedIn()) {
        redirect(url('login.php'));
    }
}

function isTeacherLoggedIn(): bool
{
    return isset($_SESSION['teacher_id'])
        && filter_var($_SESSION['teacher_id'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) !== false;
}

function requireTeacherLogin(): void
{
    if (!isTeacherLoggedIn()) {
        redirect(url('teacher/login.php'));
    }
}
