<?php
declare(strict_types=1);

if (!defined('ROOMA_APP')) {
    die('Access denied.');
}

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

sendSecurityHeaders();
requireLogin();

$logo = siteLogo();
$currentPage = basename($_SERVER['PHP_SELF']);
$adminUsername = $_SESSION['admin_username'] ?? 'مدیر';
$siteNameValue = siteName();
$pageTitleValue = isset($pageTitle) ? e($pageTitle) : 'پنل مدیریت | ' . e($siteNameValue);
$topbarTitle = isset($pageTitle) ? e(str_replace(' | ' . $siteNameValue, '', $pageTitle)) : 'پنل مدیریت';
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>(function(){var t=localStorage.getItem('roma_theme')||(window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');document.documentElement.setAttribute('data-theme',t);})();</script>
    <title><?php echo $pageTitleValue; ?></title>
    <link rel="preload" href="<?php echo e(url('assets/fonts/Vazirmatn-Regular.woff2')); ?>" as="font" type="font/woff2" crossorigin>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/fonts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/css/app-shell.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/css/admin.css')); ?>">
    <script src="<?php echo e(url('assets/js/app-shell.js')); ?>" defer></script>
    <script>
    window.toggleMobileSidebar = function(evtOrState) {
        if (evtOrState && evtOrState.stopPropagation) {
            evtOrState.stopPropagation();
        }
        var sidebar = document.getElementById('adminSidebar');
        var overlay = document.getElementById('adminOverlay');
        if (!sidebar || !overlay) return;

        var forceState = typeof evtOrState === 'boolean' ? evtOrState : null;
        var shouldOpen = forceState !== null ? forceState : !sidebar.classList.contains('active');

        if (shouldOpen) {
            sidebar.classList.add('active');
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        } else {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
        }
    };
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            window.toggleMobileSidebar(false);
        }
    });
    </script>
</head>
<body class="admin-layout">
    <div class="admin-overlay" id="adminOverlay" onclick="window.toggleMobileSidebar(false)"></div>

    <aside class="admin-sidebar" id="adminSidebar">
        <div class="admin-sidebar-header">
            <a href="<?php echo e(url('admin/index.php')); ?>" class="admin-logo">
                <?php if ($logo !== ''): ?>
                    <img src="<?php echo e(url($logo)); ?>" alt="<?php echo e($siteNameValue); ?>" class="admin-logo-img">
                <?php else: ?>
                    <span class="admin-logo-text"><svg width="18" height="18" viewBox="0 0 40 40" fill="none"><path d="M20 11c-3 0-5.5 1.5-5.5 4.2 0 1.8 1 3 2.5 3.9-.6.4-1.4 1.2-1.8 2.2-.4 1-.2 1.8.4 2.4.6.6 1.4.6 2.2.3.7-.2 1.2-1 1.5-1.5h.8c.3.5.8 1.3 1.5 1.5.8.3 1.6.3 2.2-.3.6-.6.8-1.4.4-2.4-.4-1-1.2-1.8-1.8-2.2 1.5-.9 2.5-2.1 2.5-3.9 0-2.7-2.5-4.2-5.5-4.2z" fill="white"/><circle cx="17.5" cy="15.5" r="1" fill="rgba(255,255,255,0.7)"/><circle cx="22.5" cy="15.5" r="1" fill="rgba(255,255,255,0.7)"/></svg> <?php echo e($siteNameValue); ?></span>
                <?php endif; ?>
                <span class="admin-logo-badge">مدیر</span>
            </a>
            <button type="button" class="admin-sidebar-close" id="adminSidebarClose" onclick="window.toggleMobileSidebar(false)" aria-label="بستن منو">&times;</button>
            <button type="button" class="admin-sidebar-toggle" id="sidebarToggle" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>

        <nav class="admin-nav" aria-label="منوی مدیریت">
            <a href="<?php echo e(url('admin/index.php')); ?>" class="admin-nav-item <?php echo $currentPage === 'index.php' ? 'active' : ''; ?>">
                <span class="nav-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg></span>
                <span class="nav-text">داشبورد</span>
            </a>

<?php
$isContentActive = in_array($currentPage, ['slides.php', 'gallery.php', 'news.php', 'pages.php'], true);
$isChildrenActive = in_array($currentPage, ['children.php', 'child-detail.php', 'attendance.php', 'classrooms.php', 'parents.php'], true);
$isFinanceActive = in_array($currentPage, ['tuition.php', 'salary.php', 'expenses.php', 'reports.php'], true);
?>
<script>
function toggleAdminSubmenu(btn, id) {
    var sub = document.getElementById('submenu-' + id);
    if (!sub) return;
    var isOpen = sub.classList.contains('open') || sub.classList.contains('active') || sub.style.display === 'flex';
    if (isOpen) {
        btn.setAttribute('aria-expanded', 'false');
        btn.classList.remove('active');
        sub.classList.remove('open', 'active');
        sub.style.display = 'none';
    } else {
        btn.setAttribute('aria-expanded', 'true');
        btn.classList.add('active');
        sub.classList.add('open', 'active');
        sub.style.display = 'flex';
    }
}
</script>
            <div class="admin-nav-group">
                <button type="button" class="admin-nav-item admin-nav-parent <?php echo $isContentActive ? 'active' : ''; ?>" onclick="toggleAdminSubmenu(this, 'content')" aria-expanded="<?php echo $isContentActive ? 'true' : 'false'; ?>">
                    <span class="nav-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></span>
                    <span class="nav-text">محتوا</span>
                    <span class="nav-arrow">&#8250;</span>
                </button>
                <div class="admin-nav-submenu <?php echo $isContentActive ? 'open active' : ''; ?>" id="submenu-content" style="<?php echo $isContentActive ? 'display:flex;' : 'display:none;'; ?>">
                    <a href="<?php echo e(url('admin/slides.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'slides.php' ? 'active' : ''; ?>">
                        <span class="nav-text">اسلایدها</span>
                    </a>
                    <a href="<?php echo e(url('admin/gallery.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'gallery.php' ? 'active' : ''; ?>">
                        <span class="nav-text">گالری تصاویر</span>
                    </a>
                    <a href="<?php echo e(url('admin/news.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'news.php' ? 'active' : ''; ?>">
                        <span class="nav-text">اخبار</span>
                    </a>
                    <a href="<?php echo e(url('admin/pages.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'pages.php' ? 'active' : ''; ?>">
                        <span class="nav-text">صفحات</span>
                    </a>
                </div>
            </div>

            <a href="<?php echo e(url('admin/teachers.php')); ?>" class="admin-nav-item <?php echo $currentPage === 'teachers.php' ? 'active' : ''; ?>">
                <span class="nav-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg></span>
                <span class="nav-text">معلمان</span>
            </a>

            <div class="admin-nav-group">
                <button type="button" class="admin-nav-item admin-nav-parent <?php echo $isChildrenActive ? 'active' : ''; ?>" onclick="toggleAdminSubmenu(this, 'children')" aria-expanded="<?php echo $isChildrenActive ? 'true' : 'false'; ?>">
                    <span class="nav-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 10-16 0"/></svg></span>
                    <span class="nav-text">کودکان</span>
                    <span class="nav-arrow">&#8250;</span>
                </button>
                <div class="admin-nav-submenu <?php echo $isChildrenActive ? 'open active' : ''; ?>" id="submenu-children" style="<?php echo $isChildrenActive ? 'display:flex;' : 'display:none;'; ?>">
                    <a href="<?php echo e(url('admin/children.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'children.php' || $currentPage === 'child-detail.php' ? 'active' : ''; ?>">
                        <span class="nav-text">تمام کودکان</span>
                    </a>
                    <a href="<?php echo e(url('admin/attendance.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'attendance.php' ? 'active' : ''; ?>">
                        <span class="nav-text">حضور و غیاب</span>
                    </a>
                    <a href="<?php echo e(url('admin/classrooms.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'classrooms.php' ? 'active' : ''; ?>">
                        <span class="nav-text">کلاس‌ها</span>
                    </a>

                    <a href="<?php echo e(url('admin/parents.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'parents.php' ? 'active' : ''; ?>">
                        <span class="nav-text">مدیریت والدین</span>
                    </a>                </div>
            </div>

            <div class="admin-nav-group">
                <button type="button" class="admin-nav-item admin-nav-parent <?php echo $isFinanceActive ? 'active' : ''; ?>" onclick="toggleAdminSubmenu(this, 'finance')" aria-expanded="<?php echo $isFinanceActive ? 'true' : 'false'; ?>">
                    <span class="nav-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg></span>
                    <span class="nav-text">مالی</span>
                    <span class="nav-arrow">&#8250;</span>
                </button>
                <div class="admin-nav-submenu <?php echo $isFinanceActive ? 'open active' : ''; ?>" id="submenu-finance" style="<?php echo $isFinanceActive ? 'display:flex;' : 'display:none;'; ?>">

                    <a href="<?php echo e(url('admin/tuition.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'tuition.php' ? 'active' : ''; ?>">
                        <span class="nav-text">شهریه</span>
                    </a>
                    <a href="<?php echo e(url('admin/salary.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'salary.php' ? 'active' : ''; ?>">
                        <span class="nav-text">حقوق</span>
                    </a>
                    <a href="<?php echo e(url('admin/expenses.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'expenses.php' ? 'active' : ''; ?>">
                        <span class="nav-text">هزینه‌ها</span>
                    </a>
                    <a href="<?php echo e(url('admin/reports.php')); ?>" class="admin-nav-subitem <?php echo $currentPage === 'reports.php' ? 'active' : ''; ?>">
                        <span class="nav-text">گزارش مالی</span>
                    </a>
                </div>
            </div>

            <div class="admin-nav-section">ارتباطات</div>

            <a href="<?php echo e(url('admin/events.php')); ?>" class="admin-nav-item <?php echo $currentPage === 'events.php' ? 'active' : ''; ?>">
                <span class="nav-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></span>
                <span class="nav-text">رویدادها</span>
            </a>


            <a href="<?php echo e(url('admin/messages.php')); ?>" class="admin-nav-item <?php echo $currentPage === 'messages.php' ? 'active' : ''; ?>">
                <span class="nav-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg></span>
                <span class="nav-text">پیام‌ها</span>
            </a>

            <a href="<?php echo e(url('admin/audit.php')); ?>" class="admin-nav-item <?php echo $currentPage === 'audit.php' ? 'active' : ''; ?>">
                <span class="nav-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg></span>
                <span class="nav-text">گزارش فعالیت‌ها</span>
            </a>

            <a href="<?php echo e(url('admin/backup.php')); ?>" class="admin-nav-item <?php echo $currentPage === 'backup.php' ? 'active' : ''; ?>">
                <span class="nav-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg></span>
                <span class="nav-text">پشتیبان‌گیری</span>
            </a>

            <div class="admin-nav-divider"></div>

            <a href="<?php echo e(url('admin/settings.php')); ?>" class="admin-nav-item <?php echo $currentPage === 'settings.php' ? 'active' : ''; ?>">
                <span class="nav-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg></span>
                <span class="nav-text">تنظیمات</span>
            </a>

            <form method="post" action="<?php echo e(url('admin/logout.php')); ?>" class="admin-nav-logout-form">
                <input type="hidden" name="csrf_token" value="<?php echo e(generateCsrfToken()); ?>">
                <button type="submit" class="admin-nav-item admin-nav-logout">
                    <span class="nav-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg></span>
                    <span class="nav-text">خروج</span>
                </button>
            </form>
        </nav>

        <div class="admin-sidebar-footer">
            <div class="admin-user-info">
                <div class="admin-user-avatar"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
                <div class="admin-user-details">
                    <div class="admin-user-name"><?php echo e($adminUsername); ?></div>
                    <div class="admin-user-role"><?php echo e(adminRoleLabel(currentAdminRole())); ?></div>
                </div>
            </div>
        </div>
    </aside>

    <div class="admin-main">
        <?php require_once __DIR__ . '/../templates/app/topbar.php'; ?>

        <main class="admin-content">
            <!-- Default-password warning removed (hardened: no hardcoded default password exists) -->
