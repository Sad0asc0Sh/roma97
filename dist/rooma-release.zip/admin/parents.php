<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/error_handler.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/audit.php';

requireLogin();
$currentAdminId = (int) ($_SESSION['admin_id'] ?? 0);
if (isPostRequest()) {
    $csrf=$_POST['csrf_token']??''; $action=(string)($_POST['action']??'');
    $pid=filter_var($_POST['parent_id']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
    $pid=is_int($pid)?$pid:0;
    if (!validateCsrfToken($csrf)){setFlash('error','درخواست نامعتبر.');redirect(url('admin/parents.php'));}
    try {
        initializeFinancialTables();
        $pdo=getDb();
        if($pid===0){setFlash('error','شناسه نامعتبر.');redirect(url('admin/parents.php'));}
        $chk=$pdo->prepare('SELECT id,first_name,last_name,email,status FROM parents WHERE id=:id LIMIT 1');
        $chk->execute([':id'=>$pid]); $par=$chk->fetch();
        if(!$par){setFlash('error','یافت نشد.');redirect(url('admin/parents.php'));}

        if ($action === 'generate_reset_link') {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            $ins = $pdo->prepare(
                'INSERT INTO password_reset_tokens (token, account_type, account_id, created_by_admin_id, expires_at)
                 VALUES (:token, "parent", :pid, :aid, :exp)'
            );
            $ins->execute([
                ':token' => $token,
                ':pid' => $pid,
                ':aid' => $currentAdminId > 0 ? $currentAdminId : null,
                ':exp' => $expires,
            ]);
            recordAudit('parent.generate_reset_link', 'parent', $pid);
            setFlash('reset_link_url', url('reset-password.php?token=' . urlencode($token)));
            redirect(url('admin/parents.php'));
        }

        $updates=['approve'=>'active','reject'=>'suspended','suspend'=>'suspended','activate'=>'active'];
        if(array_key_exists($action,$updates)){
            $ns=$updates[$action];
            $pdo->prepare('UPDATE parents SET status=:s WHERE id=:id')->execute([':s'=>$ns,':id'=>$pid]);
            $msgs=['approve'=>'حساب والد تأیید و فعال شد.','reject'=>'حساب والد رد شد.','suspend'=>'حساب والد مسدود شد.','activate'=>'حساب والد فعال شد.'];
            recordAudit('parent.'.$action,'parent',$pid,['status'=>$ns]);
            setFlash('success',$msgs[$action]);
        } else { setFlash('error','عملیات نامعتبر.'); }
        redirect(url('admin/parents.php'));
    } catch(Throwable $e){error_log($e->getMessage());setFlash('error','خطا.');redirect(url('admin/parents.php'));}
}

$pdo=getDb();
$sf=strtolower(trim((string)($_GET['status']??'all')));
if(!in_array($sf,['all','pending','active','suspended'],true))$sf='all';
$pp=20;$cp=max(1,(int)($_GET['page']??1));
if($sf==='all'){$total=(int)$pdo->query('SELECT COUNT(*) FROM parents')->fetchColumn();}
else{$ct=$pdo->prepare('SELECT COUNT(*) FROM parents WHERE status=:s');$ct->execute([':s'=>$sf]);$total=(int)$ct->fetchColumn();}
$tp=max(1,(int)ceil($total/$pp));$cp=min($cp,$tp);$off=($cp-1)*$pp;
$sql='SELECT id,first_name,last_name,email,phone,status,created_at FROM parents';
if($sf!=='all')$sql.=' WHERE status=:s';
$sql.=' ORDER BY created_at DESC LIMIT '.$pp.' OFFSET '.$off;
$stmt=$pdo->prepare($sql);
if($sf!=='all'){$stmt->execute([':s'=>$sf]);}else{$stmt->execute();}
$parents=$stmt->fetchAll();
$pagi=['current'=>$cp,'totalPages'=>$tp,'total'=>$total,'perPage'=>$pp,'from'=>$total>0?$off+1:0,'to'=>min($off+$pp,$total)];

$pageTitle='parents | '.siteName();
require_once __DIR__.'/header.php';
$fHref=static fn(string $v):string=>url('admin/parents.php?'.http_build_query(['status'=>$v]));
$fe=getFlash('error');$fs=getFlash('success');$resetLinkUrl=getFlash('reset_link_url');
?>
<section class="dashboard">
    <div class="app-toolbar">
        <h1 class="m-0 font-bold">مدیریت والدین</h1>
    </div>

    <?php if(!empty($resetLinkUrl)):?>
        <div class="card" style="padding:16px; margin-bottom:20px; border-right:4px solid var(--adm-primary,#3182ce);">
            <div style="font-weight:700; margin-bottom:8px;">🔑 لینک بازیابی رمز عبور تولید شد (اعتبار: ۱ ساعت):</div>
            <div style="display:flex; gap:10px; align-items:center;">
                <input type="text" value="<?=e($resetLinkUrl)?>" readonly onclick="this.select()" style="flex:1; padding:8px 12px; border-radius:6px; border:1px solid #cbd5e0; font-family:monospace; direction:ltr;">
                <button type="button" class="btn btn-secondary" onclick="navigator.clipboard.writeText('<?=e($resetLinkUrl)?>'); alert('لینک در حافظه کپی شد.');">کپی لینک</button>
            </div>
        </div>
    <?php endif;?>

    <?php if(!empty($fe)):?><div class="alert alert-error" style="margin-bottom:16px;"><?=e($fe)?></div><?php endif;?>
    <?php if(!empty($fs)):?><div class="alert alert-success" style="margin-bottom:16px;"><?=e($fs)?></div><?php endif;?>

    <div class="teacher-filters" style="margin-bottom:20px;">
        <strong>فیلتر:</strong>
        <a href="<?=$fHref('all')?>" class="filter-chip <?=$sf==='all'?'active':''?>">همه</a>
        <a href="<?=$fHref('pending')?>" class="filter-chip <?=$sf==='pending'?'active':''?>">در انتظار</a>
        <a href="<?=$fHref('active')?>" class="filter-chip <?=$sf==='active'?'active':''?>">فعال</a>
        <a href="<?=$fHref('suspended')?>" class="filter-chip <?=$sf==='suspended'?'active':''?>">مسدود</a>
    </div>
    <?php if($parents===[]):?>
        <div class="empty-state empty-state-sm">
            <div class="empty-state-icon">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
            </div>
            <h3>والدی یافت نشد</h3>
            <p><?=$sf==='pending'?'ثبت نام جدیدی در انتظار تأیید نیست.':'لیست خالی است.'?></p>
        </div>
    <?php else:?>
        <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>نام</th><th>ایمیل</th><th>تلفن</th><th>وضعیت</th><th>تاریخ</th><th>عملیات</th></tr></thead><tbody>
        <?php foreach($parents as $p):?>
            <tr>
                <td style="font-weight:600"><?=e($p['first_name'].' '.$p['last_name'])?></td>
                <td style="font-size:0.85rem"><?=e($p['email'])?></td>
                <td><?=e($p['phone']??'—')?></td>
                <td><?php $bc=match($p['status']){'active'=>'badge-success','pending'=>'badge-warning','suspended'=>'badge-danger',default=>'badge-info'};$sl=match($p['status']){'active'=>'فعال','pending'=>'در انتظار تأیید','suspended'=>'مسدود',default=>$p['status']};?><span class="badge <?=$bc?>"><?=$sl?></span></td>
                <td style="font-size:0.85rem;color:var(--muted)"><?=e(shamsiDate((string)$p['created_at']))?></td>
                <td>
                    <?php if($p['status']==='pending'):?>
                        <form method="post" action="<?=e(url('admin/parents.php'))?>" style="display:inline"><input type="hidden" name="csrf_token" value="<?=e(generateCsrfToken())?>"><input type="hidden" name="action" value="approve"><input type="hidden" name="parent_id" value="<?=$p['id']?>"><button type="submit" class="btn btn-sm btn-success">تأیید</button></form>
                        <form method="post" action="<?=e(url('admin/parents.php'))?>" style="display:inline" onsubmit="return confirm('رد شود؟')"><input type="hidden" name="csrf_token" value="<?=e(generateCsrfToken())?>"><input type="hidden" name="action" value="reject"><input type="hidden" name="parent_id" value="<?=$p['id']?>"><button type="submit" class="btn btn-sm btn-reject">رد</button></form>
                    <?php elseif($p['status']==='active'):?>
                        <form method="post" action="<?=e(url('admin/parents.php'))?>" style="display:inline" onsubmit="return confirm('مسدود شود؟')"><input type="hidden" name="csrf_token" value="<?=e(generateCsrfToken())?>"><input type="hidden" name="action" value="suspend"><input type="hidden" name="parent_id" value="<?=$p['id']?>"><button type="submit" class="btn btn-sm btn-muted">مسدود</button></form>
                    <?php else:?>
                        <form method="post" action="<?=e(url('admin/parents.php'))?>" style="display:inline"><input type="hidden" name="csrf_token" value="<?=e(generateCsrfToken())?>"><input type="hidden" name="action" value="activate"><input type="hidden" name="parent_id" value="<?=$p['id']?>"><button type="submit" class="btn btn-sm btn-success">فعال‌سازی</button></form>
                    <?php endif;?>
                    <form method="post" action="<?=e(url('admin/parents.php'))?>" style="display:inline"><input type="hidden" name="csrf_token" value="<?=e(generateCsrfToken())?>"><input type="hidden" name="action" value="generate_reset_link"><input type="hidden" name="parent_id" value="<?=$p['id']?>"><button type="submit" class="btn btn-sm btn-secondary" title="ساخت لینک بازیابی رمز عبور">🔑 بازیابی رمز</button></form>
                </td>
            </tr>
        <?php endforeach;?>
        </tbody></table></div>
        <?php if($pagi['total']>$pagi['perPage']):?>
            <p class="pagination-summary">نمایش <?=e(persianNumber($pagi['from']))?> تا <?=e(persianNumber($pagi['to']))?> از <?=e(persianNumber($pagi['total']))?> والد</p>
            <?=renderPagination($pagi,url('admin/parents.php'),$sf!=='all'?['status'=>$sf]:[])?>
        <?php endif;?>
    <?php endif;?>
</section>
<?php require_once __DIR__.'/footer.php';?>